create
    definer = ``@`` procedure getById(IN idd int)
BEGIN
	SELECT *  FROM customers where id = idd ;
END;

